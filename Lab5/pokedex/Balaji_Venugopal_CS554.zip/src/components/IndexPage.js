import React from 'react';

const IndexPage = () => {
return (
    <div>
        
        <div className="intro">
            <p>All the Pokémon data you'll ever need in one place! Pokémon are the creatures that inhabit the world of the Pokémon games. They can be caught using Pokéballs and trained by battling with other Pokémon.</p>
        </div>
    </div>
)
}

export default IndexPage;

