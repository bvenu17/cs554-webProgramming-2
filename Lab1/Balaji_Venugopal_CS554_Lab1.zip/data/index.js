const taskData = require("./task");
const commentData = require("./comments");

module.exports = {
  task: taskData,
  comments:commentData
};